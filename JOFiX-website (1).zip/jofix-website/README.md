# JOFiX — Your Trusted Problem Solver

A clean, premium, personal, mobile-first static website for JOFiX.

## Put the brand assets here

Replace these two files with the actual JOFiX assets:

- `assets/jofix-logo.png` — the uploaded JOFiX logo
- `assets/yousef-hujouj.jpg` — the professional founder photo

The site already has graceful visual fallbacks if an asset is missing.

## Run locally

No build step is required.

1. Keep the folder structure intact.
2. Open `index.html` in a browser.

For a more realistic local server, use VS Code + Live Server, or any simple static server.

## Deploy to GitHub Pages

1. Create a GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, and the `assets` folder.
3. In GitHub: Settings → Pages.
4. Choose the main branch and root folder.
5. Save.

## Contact rule

The only contact method intentionally included is:

`tel:+40732577262`

No email, forms, address, social links, or other contact numbers are included.

## SEO

The page includes:
- Semantic HTML sections
- Title and meta description
- Open Graph basics
- Responsive viewport
- Accessible skip link
- Descriptive image alt text
- Reduced-motion support
